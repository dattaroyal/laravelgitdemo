<div class="flex gap-x-1 w-full items-center">
    <div class="shimmer w-[302px] h-[38px] rounded-lg"></div>

    <div class="ltr:pl-2.5 rtl:pr-2.5">
        <p class="shimmer w-[75px] h-[17px]"></p>
    </div>
</div>
