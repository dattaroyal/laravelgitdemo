<table {{ $attributes->merge(['class' => 'w-full min-w-[800px] text-left text-sm']) }}>
    {{ $slot }}
</table>

